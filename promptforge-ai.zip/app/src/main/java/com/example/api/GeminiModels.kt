package com.example.api

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    @Json(name = "contents") val contents: List<Content>,
    @Json(name = "generationConfig") val generationConfig: GenerationConfig? = null,
    @Json(name = "systemInstruction") val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    @Json(name = "parts") val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    @Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    @Json(name = "responseMimeType") val responseMimeType: String? = null,
    @Json(name = "temperature") val temperature: Float? = null,
    @Json(name = "topP") val topP: Float? = null,
    @Json(name = "topK") val topK: Int? = null
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<Candidate>?
)

@JsonClass(generateAdapter = true)
data class Candidate(
    @Json(name = "content") val content: Content?
)

// --- Our Custom App Creator Output Structures ---

@JsonClass(generateAdapter = true)
data class GeneratedProjectResult(
    @Json(name = "name") val name: String,
    @Json(name = "type") val type: String, // "WEBSITE" or "ANDROID_APP"
    @Json(name = "sourceCode") val sourceCode: String, // Full HTML or Kotlin Code
    @Json(name = "previewConfig") val previewConfig: PreviewConfig? = null
)

@JsonClass(generateAdapter = true)
data class PreviewConfig(
    @Json(name = "themeColor") val themeColor: String? = "#6200EE",
    @Json(name = "components") val components: List<PreviewComponent>? = emptyList()
)

@JsonClass(generateAdapter = true)
data class PreviewComponent(
    @Json(name = "type") val type: String, // "header", "text", "button", "textField", "card", "switch", "checkbox", "imagePlaceholder", "spacer"
    @Json(name = "label") val label: String? = null,
    @Json(name = "text") val text: String? = null,
    @Json(name = "title") val title: String? = null,
    @Json(name = "subtitle") val subtitle: String? = null,
    @Json(name = "placeholder") val placeholder: String? = null,
    @Json(name = "icon") val icon: String? = null, // e.g. "home", "star", "settings", "person"
    @Json(name = "actionMessage") val actionMessage: String? = null, // toast/snackbar when interactive item clicked
    @Json(name = "heightDp") val heightDp: Int? = null
)

@JsonClass(generateAdapter = true)
data class GeneratedStoreListing(
    @Json(name = "title") val title: String,
    @Json(name = "shortDescription") val shortDescription: String,
    @Json(name = "fullDescription") val fullDescription: String
)
