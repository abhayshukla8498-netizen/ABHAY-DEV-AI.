package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Label
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.api.GeneratedStoreListing
import com.example.ui.ProjectViewModel
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioPurple
import com.example.ui.theme.StudioTeal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublisherScreen(
    viewModel: ProjectViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Listing ASO", "Privacy Policy", "Build Checklist", "Keystore tool")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Google Play Console Suite", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Publish your creations like a pro", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back Arrow")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tab Row Navigation
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = StudioPurple
                    )
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (selectedTab) {
                    0 -> AsoListingTab(viewModel)
                    1 -> PrivacyPolicyTab()
                    2 -> ChecklistTab()
                    3 -> KeystoreTab()
                }
            }
        }
    }
}

@Composable
fun AsoListingTab(viewModel: ProjectViewModel) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var appTheme by remember { mutableStateOf("") }
    var tone by remember { mutableStateOf("Professional & Energetic") }
    var isGenerating by remember { mutableStateOf(false) }
    var generatedListing by remember { mutableStateOf<GeneratedStoreListing?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = StudioBlue.copy(alpha = 0.1f))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.AutoAwesome, "AI Icon", tint = StudioBlue)
                Column {
                    Text("AI Store Listing Optimizer", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Generate high-converting titles and description using Google Gemini API.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                }
            }
        }

        OutlinedTextField(
            value = appTheme,
            onValueChange = { appTheme = it },
            label = { Text("App Concept / Description") },
            placeholder = { Text("e.g. A daily habit tracker with graphs, streak calendar, and colorful widgets") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = tone,
            onValueChange = { tone = it },
            label = { Text("Tone / Style") },
            placeholder = { Text("e.g. Professional, Casual, Energetic, Minimalist") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        Button(
            onClick = {
                if (appTheme.isBlank()) {
                    Toast.makeText(context, "Please enter your app concept first", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                isGenerating = true
                errorMessage = null
                generatedListing = null
                viewModel.optimizeStoreListing(
                    appTheme = appTheme,
                    tone = tone,
                    onSuccess = { listing ->
                        isGenerating = false
                        generatedListing = listing
                    },
                    onError = { err ->
                        isGenerating = false
                        errorMessage = err
                    }
                )
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = StudioBlue),
            enabled = !isGenerating
        ) {
            if (isGenerating) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Optimizing listing...")
            } else {
                Icon(Icons.Default.Bolt, "Lightning")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Generate Optimized Listing", fontWeight = FontWeight.Bold)
            }
        }

        errorMessage?.let { err ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(err, color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
            }
        }

        animatedContentListing(generatedListing, clipboardManager, context)
    }
}

@Composable
fun animatedContentListing(
    generatedListing: GeneratedStoreListing?,
    clipboardManager: androidx.compose.ui.platform.ClipboardManager,
    context: android.content.Context
) {
    AnimatedVisibility(
        visible = generatedListing != null,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically()
    ) {
        generatedListing?.let { listing ->
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                HorizontalDivider()
                Text("Generated ASO Assets", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                // 1. App Title Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("APP TITLE (Max 30 Chars)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = StudioPurple)
                            IconButton(onClick = {
                                clipboardManager.setText(AnnotatedString(listing.title))
                                Toast.makeText(context, "Title copied!", Toast.LENGTH_SHORT).show()
                            }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.ContentCopy, "Copy Title", modifier = Modifier.size(16.dp))
                            }
                        }
                        Text(listing.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    }
                }

                // 2. Short Description Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("SHORT DESCRIPTION (Max 80 Chars)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = StudioTeal)
                            IconButton(onClick = {
                                clipboardManager.setText(AnnotatedString(listing.shortDescription))
                                Toast.makeText(context, "Short Description copied!", Toast.LENGTH_SHORT).show()
                            }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.ContentCopy, "Copy Short Desc", modifier = Modifier.size(16.dp))
                            }
                        }
                        Text(listing.shortDescription, fontSize = 13.sp)
                    }
                }

                // 3. Full Description Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("FULL STORE DESCRIPTION (Max 4000 Chars)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = StudioBlue)
                            IconButton(onClick = {
                                clipboardManager.setText(AnnotatedString(listing.fullDescription))
                                Toast.makeText(context, "Full Description copied!", Toast.LENGTH_SHORT).show()
                            }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.ContentCopy, "Copy Full Desc", modifier = Modifier.size(16.dp))
                            }
                        }
                        Text(listing.fullDescription, fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun PrivacyPolicyTab() {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var appName by remember { mutableStateOf("") }
    var devEmail by remember { mutableStateOf("") }
    var devName by remember { mutableStateOf("") }
    var includeFirebase by remember { mutableStateOf(true) }
    var generatedPolicy by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = StudioTeal.copy(alpha = 0.1f))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.VerifiedUser, "Security Icon", tint = StudioTeal)
                Column {
                    Text("Instant Privacy Policy Builder", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Google Play requires a public privacy policy URL. Generate standard compliant policy text below.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                }
            }
        }

        OutlinedTextField(
            value = appName,
            onValueChange = { appName = it },
            label = { Text("Application Name") },
            placeholder = { Text("e.g. Space Tracker") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = devEmail,
            onValueChange = { devEmail = it },
            label = { Text("Support Email") },
            placeholder = { Text("e.g. contact@domain.com") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = devName,
            onValueChange = { devName = it },
            label = { Text("Developer / Company Name") },
            placeholder = { Text("e.g. Abhay Shukla") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Include Firebase Analytics & Ads policy terms", fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Switch(checked = includeFirebase, onCheckedChange = { includeFirebase = it })
        }

        Button(
            onClick = {
                if (appName.isBlank() || devEmail.isBlank() || devName.isBlank()) {
                    Toast.makeText(context, "Please fill in all details above", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                generatedPolicy = buildPrivacyPolicyHtml(appName, devEmail, devName, includeFirebase)
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = StudioTeal)
        ) {
            Icon(Icons.Default.Build, "Generate")
            Spacer(modifier = Modifier.width(6.dp))
            Text("Generate Privacy Policy HTML", fontWeight = FontWeight.Bold)
        }

        if (generatedPolicy.isNotEmpty()) {
            HorizontalDivider()
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("HTML Code (Copy and upload to hosting / Google Sites)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                IconButton(onClick = {
                    clipboardManager.setText(AnnotatedString(generatedPolicy))
                    Toast.makeText(context, "HTML Privacy Policy copied!", Toast.LENGTH_SHORT).show()
                }) {
                    Icon(Icons.Default.ContentCopy, "Copy HTML")
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(Color(0xFF0F172A), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                    .padding(12.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = generatedPolicy,
                    color = Color(0xFFE2E8F0),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
        }
    }
}

private fun buildPrivacyPolicyHtml(appName: String, email: String, devName: String, includeFirebase: StringList): String {
    return """
<!DOCTYPE html>
<html>
<head>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width'>
  <title>Privacy Policy - $appName</title>
  <style> body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding:1em; line-height: 1.6; } </style>
</head>
<body>
<h2>Privacy Policy</h2>
<p>
  $devName built the $appName app as a Commercial app. This SERVICE is provided by
  $devName and is intended for use as is.
</p>
<p>
  This page is used to inform visitors regarding our policies with the collection, use, and disclosure
  of Personal Information if anyone decided to use our Service.
</p>
<p>
  If you choose to use our Service, then you agree to the collection and use of information in
  relation to this policy. The Personal Information that we collect is used for providing and improving
  the Service. We will not use or share your information with anyone except as described in this Privacy Policy.
</p>
<p><strong>Information Collection and Use</strong></p>
<p>
  For a better experience, while using our Service, we may require you to provide us with certain
  personally identifiable information. The information that we request will be retained by us and used as described in this privacy policy.
</p>
${if (includeFirebase) """
<p>
  The app does use third-party services that may collect information used to identify you.
  Link to the privacy policy of third-party service providers used by the app:
</p>
<ul>
  <li><a href="https://www.google.com/policies/privacy/" target="_blank" rel="noopener noreferrer">Google Play Services</a></li>
  <li><a href="https://firebase.google.com/policies/analytics" target="_blank" rel="noopener noreferrer">Google Analytics for Firebase</a></li>
</ul>
""" else ""}
<p><strong>Log Data</strong></p>
<p>
  We want to inform you that whenever you use our Service, in a case of an error in the app we collect
  data and information (through third-party products) on your phone called Log Data. This Log Data may
  include information such as your device Internet Protocol (“IP”) address, device name, operating system
  version, the configuration of the app when utilizing our Service, the time and date of your use of the
  Service, and other statistics.
</p>
<p><strong>Cookies</strong></p>
<p>
  Cookies are files with a small amount of data that are commonly used as anonymous unique identifiers.
  These are sent to your browser from the websites that you visit and are stored on your device's internal memory.
</p>
<p><strong>Security</strong></p>
<p>
  We value your trust in providing us your Personal Information, thus we are striving to use commercially
  acceptable means of protecting it. But remember that no method of transmission over the internet, or
  method of electronic storage is 100% secure and reliable, and we cannot guarantee its absolute security.
</p>
<p><strong>Contact Us</strong></p>
<p>
  If you have any questions or suggestions about our Privacy Policy, do not hesitate to contact us at
  <strong>$email</strong>.
</p>
</body>
</html>
    """.trimIndent()
}

// Simple helper type to represent boolean in privacy policy generator
private typealias StringList = Boolean

@Composable
fun ChecklistTab() {
    var check1 by remember { mutableStateOf(false) }
    var check2 by remember { mutableStateOf(false) }
    var check3 by remember { mutableStateOf(false) }
    var check4 by remember { mutableStateOf(false) }
    var check5 by remember { mutableStateOf(false) }
    var check6 by remember { mutableStateOf(false) }

    val checkedCount = listOf(check1, check2, check3, check4, check5, check6).count { it }
    val progress = checkedCount / 6f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = StudioPurple.copy(alpha = 0.1f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Play Store Release Readiness", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = StudioPurple)
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    color = StudioPurple,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Text("Completed $checkedCount of 6 tasks (${(progress * 100).toInt()}%)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Text("Launch Requirements List", fontWeight = FontWeight.Bold, fontSize = 14.sp)

        ChecklistItem(
            title = "Adaptive App Icon (512x512 PNG)",
            description = "A beautiful square application icon with no transparency/alpha layer to display on Play Store shelves.",
            checked = check1,
            onCheckedChange = { check1 = it }
        )

        ChecklistItem(
            title = "Feature Graphic Artwork (1024x500 PNG)",
            description = "A colorful high-resolution promotional cover photo that represents your app's main branding.",
            checked = check2,
            onCheckedChange = { check2 = it }
        )

        ChecklistItem(
            title = "At least 2 screenshots (Max 8)",
            description = "High fidelity device mockup screenshots. Must be 16:9 or 9:16 aspect ratio up to 8MB in size.",
            checked = check3,
            onCheckedChange = { check3 = it }
        )

        ChecklistItem(
            title = "Valid Signed Release Bundle (.aab)",
            description = "An Android App Bundle built using gradle tasks. Contains standard release optimized packages.",
            checked = check4,
            onCheckedChange = { check4 = it }
        )

        ChecklistItem(
            title = "Privacy Policy Public URL Link",
            description = "Must host a public privacy policy HTML file (generated in the previous tab) and link it in Play Console.",
            checked = check5,
            onCheckedChange = { check5 = it }
        )

        ChecklistItem(
            title = "Target Android SDK 34+",
            description = "Your build.gradle configuration target SDK must be level 34 (Android 14) or higher for Play Store compliance.",
            checked = check6,
            onCheckedChange = { check6 = it }
        )
    }
}

@Composable
fun ChecklistItem(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) },
        colors = CardDefaults.cardColors(
            containerColor = if (checked) StudioPurple.copy(alpha = 0.05f) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            1.dp,
            if (checked) StudioPurple.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Checkbox(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = CheckboxDefaults.colors(checkedColor = StudioPurple)
            )
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium, lineHeight = 15.sp)
            }
        }
    }
}

@Composable
fun KeystoreTab() {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var keystoreName by remember { mutableStateOf("release-key.keystore") }
    var keyAlias by remember { mutableStateOf("app-alias") }
    var keyPassword by remember { mutableStateOf("password123") }
    var validityDays by remember { mutableStateOf("10000") }
    var commonName by remember { mutableStateOf("My Dev Team") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = StudioPurple.copy(alpha = 0.1f))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.Key, "Key Icon", tint = StudioPurple)
                Column {
                    Text("Signed Release Keystore Creator", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("To release an app on the Play Store, it must be signed with a secure cryptographic key file.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                }
            }
        }

        OutlinedTextField(
            value = keystoreName,
            onValueChange = { keystoreName = it },
            label = { Text("Keystore Filename") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = keyAlias,
            onValueChange = { keyAlias = it },
            label = { Text("Key Alias") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = keyPassword,
            onValueChange = { keyPassword = it },
            label = { Text("Key Password") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = validityDays,
            onValueChange = { validityDays = it },
            label = { Text("Validity (In Days)") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = commonName,
            onValueChange = { commonName = it },
            label = { Text("Developer / Common Name (CN)") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        val generatedCmd = "keytool -genkey -v -keystore $keystoreName -alias $keyAlias -keyalg RSA -keysize 2048 -validity $validityDays -storepass $keyPassword -keypass $keyPassword -dname \"CN=$commonName\""

        HorizontalDivider()

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Generate Terminal Command", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            IconButton(onClick = {
                clipboardManager.setText(AnnotatedString(generatedCmd))
                Toast.makeText(context, "Terminal command copied!", Toast.LENGTH_SHORT).show()
            }) {
                Icon(Icons.Default.ContentCopy, "Copy command")
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F172A), RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text(
                text = generatedCmd,
                color = Color(0xFF38BDF8),
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("How to sign your app:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("1. Paste the copied keytool command into your computer terminal to generate the keystore file.", fontSize = 11.sp)
                Text("2. Place the generated file in the 'app/' directory of your project.", fontSize = 11.sp)
                Text("3. Add release signing configuration inside app/build.gradle.kts to point to this keystore.", fontSize = 11.sp)
            }
        }
    }
}
