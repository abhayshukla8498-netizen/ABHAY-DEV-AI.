package com.example.ui

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.api.Content
import com.example.api.GenerateContentRequest
import com.example.api.GeminiClient
import com.example.api.GeneratedProjectResult
import com.example.api.GeneratedStoreListing
import com.example.api.GenerationConfig
import com.example.api.Part
import com.example.api.PreviewComponent
import com.example.api.PreviewConfig
import com.squareup.moshi.Moshi
import com.example.data.AppDatabase
import com.example.data.Project
import com.example.data.ProjectRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

sealed interface WorkspaceUiState {
    object Idle : WorkspaceUiState
    object Generating : WorkspaceUiState
    data class Success(val project: Project) : WorkspaceUiState
    data class Error(val message: String) : WorkspaceUiState
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

class ProjectViewModel(
    application: Application,
    private val repository: ProjectRepository
) : AndroidViewModel(application) {

    // SharedPreferences to persist real user session locally
    private val sharedPrefs = application.getSharedPreferences("abhay_creator_session", Context.MODE_PRIVATE)

    private val _isLoggedIn = MutableStateFlow(sharedPrefs.getBoolean("is_logged_in", false))
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _loggedInUserEmail = MutableStateFlow(sharedPrefs.getString("user_email", "") ?: "")
    val loggedInUserEmail: StateFlow<String> = _loggedInUserEmail.asStateFlow()

    private val _loggedInUserName = MutableStateFlow(sharedPrefs.getString("user_name", "") ?: "")
    val loggedInUserName: StateFlow<String> = _loggedInUserName.asStateFlow()

    fun loginUser(email: String, name: String) {
        sharedPrefs.edit().apply {
            putBoolean("is_logged_in", true)
            putString("user_email", email)
            putString("user_name", name)
            apply()
        }
        _isLoggedIn.value = true
        _loggedInUserEmail.value = email
        _loggedInUserName.value = name
    }

    fun logoutUser() {
        sharedPrefs.edit().apply {
            putBoolean("is_logged_in", false)
            putString("user_email", "")
            putString("user_name", "")
            apply()
        }
        _isLoggedIn.value = false
        _loggedInUserEmail.value = ""
        _loggedInUserName.value = ""
    }

    val allProjects: StateFlow<List<Project>> = repository.allProjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _uiState = MutableStateFlow<WorkspaceUiState>(WorkspaceUiState.Idle)
    val uiState: StateFlow<WorkspaceUiState> = _uiState.asStateFlow()

    private val _promptInput = MutableStateFlow("")
    val promptInput: StateFlow<String> = _promptInput.asStateFlow()

    private val _creationType = MutableStateFlow("WEBSITE") // "WEBSITE" or "ANDROID_APP"
    val creationType: StateFlow<String> = _creationType.asStateFlow()

    private val _selectedProject = MutableStateFlow<Project?>(null)
    val selectedProject: StateFlow<Project?> = _selectedProject.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    fun setPrompt(prompt: String) {
        _promptInput.value = prompt
    }

    fun setType(type: String) {
        _creationType.value = type
    }

    fun selectProject(project: Project?) {
        _selectedProject.value = project
        _chatMessages.value = emptyList()
        if (project != null) {
            _uiState.value = WorkspaceUiState.Success(project)
            initializeChat()
        } else {
            _uiState.value = WorkspaceUiState.Idle
        }
    }

    fun initializeChat() {
        val proj = _selectedProject.value ?: return
        if (_chatMessages.value.isEmpty()) {
            _chatMessages.value = listOf(
                ChatMessage(
                    text = "Hi! I am your AI coding partner for \"${proj.name}\". 🚀\nI can modify this project in real-time. Just tell me what you want to change, like:\n• \"Change background to a dark cosmic color theme\"\n• \"Add a contact form with email & submit button\"\n• \"Add a search bar at the top\"\n\nWhat should we build next?",
                    isUser = false
                )
            )
        }
    }

    fun addChatMessage(message: ChatMessage) {
        _chatMessages.value = _chatMessages.value + message
    }

    fun refineProjectWithAi(
        userMessage: String,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val currentProj = _selectedProject.value ?: run {
            onError("No project selected")
            return
        }

        viewModelScope.launch {
            try {
                val apiKey = GeminiClient.getApiKey()
                if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                    onError("Gemini API key is not configured. Please enter your API key in the Secrets panel in Google AI Studio.")
                    return@launch
                }

                // Construct chat history context for Gemini
                val historyString = _chatMessages.value.filter { it.text.isNotBlank() }.joinToString("\n") { msg ->
                    if (msg.isUser) "User: ${msg.text}" else "AI Assistant: [Processed modification request]"
                }

                val systemPrompt = """
                    You are an expert AI software developer who refines, modifies, and improves existing websites and Android application layouts.
                    You are given the current state of a project and the user's instructions to modify/improve it.
                    You must output a strictly formatted JSON object matching the exact structure of `GeneratedProjectResult`.
                """.trimIndent()

                val userPrompt = """
                    Current Project Details:
                    - Name: "${currentProj.name}"
                    - Type: "${currentProj.type}" (either "WEBSITE" or "ANDROID_APP")
                    - Original Prompt: "${currentProj.prompt}"

                    Current Source Code:
                    ```
                    ${currentProj.sourceCode}
                    ```

                    Current Mobile Simulation Components Config (only relevant if Android):
                    ```
                    ${currentProj.previewConfigJson}
                    ```

                    Chat History context:
                    $historyString

                    New User Modification Request:
                    "$userMessage"

                    Please modify the project according to the request. Keep the code clean, modern, and completely functional.
                    If the project is a WEBSITE:
                    - In `sourceCode`, return the modified COMPLETE HTML string. Make sure it is fully functional and responsive.
                    - Keep the `previewConfig` field null or keep components empty.

                    If the project is an ANDROID_APP:
                    - In `sourceCode`, write the updated compilable Kotlin code with all imports and a main @Composable screen.
                    - In `previewConfig`, provide a fully updated list of interactive simulation components matching the new code.
                    Supported simulation components are: header, text, button, textField, card, switch, checkbox, imagePlaceholder, spacer.

                    You MUST respond with a strictly formatted JSON object matching this structure:
                    {
                      "name": "Updated name of the project (if renamed or updated, else keep same)",
                      "type": "${currentProj.type}",
                      "sourceCode": "Insert the complete modified source code here...",
                      "previewConfig": {
                        "themeColor": "#xxxxxx",
                        "components": [
                           ... (modified list of simulated components)
                        ]
                      }
                    }

                    IMPORTANT: Return ONLY the raw JSON object. Do not wrap it in markdown block, do not include any other text before or after the JSON.
                """.trimIndent()

                val request = GenerateContentRequest(
                    contents = listOf(Content(parts = listOf(Part(text = userPrompt)))),
                    generationConfig = GenerationConfig(
                        responseMimeType = "application/json",
                        temperature = 0.3f
                    ),
                    systemInstruction = Content(
                        parts = listOf(Part(text = systemPrompt))
                    )
                )

                val response = withContext(Dispatchers.IO) {
                    GeminiClient.service.generateContent(apiKey, request)
                }

                val jsonResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (jsonResponse == null) {
                    onError("Failed to get response from Gemini. Please try again.")
                    return@launch
                }

                val result = GeminiClient.parseGeneratedProject(jsonResponse)
                if (result == null) {
                    onError("Failed to parse Gemini response as a valid project structure. Please try again with a simpler request.")
                    return@launch
                }

                val previewConfigString = if (result.type == "WEBSITE") {
                    result.sourceCode
                } else {
                    val moshi = GeminiClient.moshi
                    val adapter = moshi.adapter(PreviewConfig::class.java)
                    adapter.toJson(result.previewConfig ?: PreviewConfig())
                }

                val updatedProject = currentProj.copy(
                    name = result.name,
                    sourceCode = result.sourceCode,
                    previewConfigJson = previewConfigString
                )

                withContext(Dispatchers.IO) {
                    repository.updateProject(updatedProject)
                }

                _selectedProject.value = updatedProject
                
                val confirmMessage = "I have successfully modified the project! I've updated the source code and simulated components according to your request. You can check the changes right now in the 'Real-time Preview' and 'Source Code' tabs."
                onSuccess(confirmMessage)

            } catch (e: Exception) {
                onError("Error: ${e.localizedMessage ?: "Unknown error occurred"}")
            }
        }
    }

    fun deleteProject(projectId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteProjectById(projectId)
            if (_selectedProject.value?.id == projectId) {
                _selectedProject.value = null
                _uiState.value = WorkspaceUiState.Idle
            }
        }
    }

    fun optimizeStoreListing(
        appTheme: String,
        tone: String,
        onSuccess: (GeneratedStoreListing) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val apiKey = GeminiClient.getApiKey()
                if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                    onError("Gemini API key is not configured. Please enter your API key in the Secrets panel in Google AI Studio.")
                    return@launch
                }

                val systemPrompt = "You are an expert Google Play Store ASO (App Store Optimization) copywriter. You write compelling, high-converting store listings in Hindi, English, or any language requested."
                val userPrompt = """
                    Generate a Google Play Store listing based on the following:
                    App Concept/Theme: "$appTheme"
                    Brand Tone/Style: "$tone"

                    You must respond with a strictly formatted JSON object matching this structure:
                    {
                      "title": "Compelling, catchy app title under 30 characters",
                      "shortDescription": "Engaging short description under 80 characters highlighting main value",
                      "fullDescription": "A professional, beautiful full description up to 4000 characters. Use emojis, list key features in bullet points, explain who this app is for, and include relevant keywords naturally."
                    }

                    IMPORTANT: Return ONLY the JSON object. No markdown, no triple backticks, no conversational text.
                """.trimIndent()

                val request = GenerateContentRequest(
                    contents = listOf(Content(parts = listOf(Part(text = userPrompt)))),
                    generationConfig = GenerationConfig(
                        responseMimeType = "application/json",
                        temperature = 0.7f
                    ),
                    systemInstruction = Content(
                        parts = listOf(Part(text = systemPrompt))
                    )
                )

                val response = withContext(Dispatchers.IO) {
                    GeminiClient.service.generateContent(apiKey, request)
                }

                val jsonResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (jsonResponse == null) {
                    onError("Failed to get response from Gemini. Please try again.")
                    return@launch
                }

                val moshi = Moshi.Builder().addLast(com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory()).build()
                val adapter = moshi.adapter(GeneratedStoreListing::class.java)
                val result = adapter.fromJson(jsonResponse)
                if (result != null) {
                    onSuccess(result)
                } else {
                    onError("Failed to parse Gemini listing response.")
                }
            } catch (e: Exception) {
                onError("Error: ${e.localizedMessage ?: "Unknown error occurred"}")
            }
        }
    }

    fun generateProject(prompt: String, type: String) {
        if (prompt.isBlank()) {
            _uiState.value = WorkspaceUiState.Error("Please enter a prompt first")
            return
        }

        _uiState.value = WorkspaceUiState.Generating

        viewModelScope.launch {
            try {
                val apiKey = GeminiClient.getApiKey()
                if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                    _uiState.value = WorkspaceUiState.Error(
                        "Gemini API key is not configured. Please enter your API key in the Secrets panel in Google AI Studio."
                    )
                    return@launch
                }

                val promptText = buildPromptText(prompt, type)

                val request = GenerateContentRequest(
                    contents = listOf(Content(parts = listOf(Part(text = promptText)))),
                    generationConfig = GenerationConfig(
                        responseMimeType = "application/json",
                        temperature = 0.2f
                    ),
                    systemInstruction = Content(
                        parts = listOf(
                            Part(
                                text = "You are an elite Google AI Developer assistant that outputs strictly formatted JSON responses to generate websites and Android applications code."
                            )
                        )
                    )
                )

                val response = withContext(Dispatchers.IO) {
                    GeminiClient.service.generateContent(apiKey, request)
                }

                val jsonResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (jsonResponse == null) {
                    _uiState.value = WorkspaceUiState.Error("Failed to generate content. Please try again.")
                    return@launch
                }

                val result = GeminiClient.parseGeneratedProject(jsonResponse)
                if (result == null) {
                    _uiState.value = WorkspaceUiState.Error(
                        "The AI returned an invalid project structure. Please try a different prompt or retry."
                    )
                    return@launch
                }

                // If website, let's make sure sourceCode goes into previewConfigJson as well
                val previewConfigString = if (result.type == "WEBSITE") {
                    result.sourceCode
                } else {
                    // It's Android, serialize previewConfig back to JSON string for our simulated UI
                    val moshi = GeminiClient.moshi
                    val adapter = moshi.adapter(PreviewConfig::class.java)
                    adapter.toJson(result.previewConfig ?: PreviewConfig())
                }

                val newProject = Project(
                    name = result.name,
                    type = result.type,
                    prompt = prompt,
                    sourceCode = result.sourceCode,
                    previewConfigJson = previewConfigString
                )

                val generatedId = withContext(Dispatchers.IO) {
                    repository.insertProject(newProject)
                }

                val savedProject = newProject.copy(id = generatedId.toInt())
                _selectedProject.value = savedProject
                _uiState.value = WorkspaceUiState.Success(savedProject)
                _promptInput.value = "" // clear prompt input on success

            } catch (e: Exception) {
                _uiState.value = WorkspaceUiState.Error("Generation Error: ${e.localizedMessage ?: e.message}")
            }
        }
    }

    fun publishProject(project: Project) {
        viewModelScope.launch(Dispatchers.IO) {
            val randomString = (10000..99999).random()
            val cleanName = project.name.lowercase().replace(" ", "-")
            val publishedUrl = if (project.type == "WEBSITE") {
                "https://aidevstudio.net/w/$cleanName-$randomString"
            } else {
                "https://aidevstudio.net/apps/$cleanName-$randomString.apk"
            }

            val updatedProject = project.copy(
                isPublished = true,
                publishedUrl = publishedUrl
            )
            repository.updateProject(updatedProject)
            _selectedProject.value = updatedProject
            _uiState.value = WorkspaceUiState.Success(updatedProject)
        }
    }

    fun copyToClipboard(context: Context, text: String, label: String = "Code") {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = android.content.ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied to clipboard!", Toast.LENGTH_SHORT).show()
    }

    fun downloadCode(context: Context, project: Project) {
        viewModelScope.launch {
            val fileName = getFileName(project)
            val code = project.sourceCode
            val success = withContext(Dispatchers.IO) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val resolver = context.contentResolver
                        val contentValues = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                            put(MediaStore.MediaColumns.MIME_TYPE, if (project.type == "WEBSITE") "text/html" else "text/plain")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        }
                        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        if (uri != null) {
                            resolver.openOutputStream(uri)?.use { out ->
                                out.write(code.toByteArray())
                            }
                            true
                        } else {
                            false
                        }
                    } else {
                        val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                        if (!downloadDir.exists()) downloadDir.mkdirs()
                        val file = File(downloadDir, fileName)
                        FileOutputStream(file).use { out ->
                            out.write(code.toByteArray())
                        }
                        true
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    false
                }
            }

            if (success) {
                Toast.makeText(context, "Successfully saved to Downloads: $fileName", Toast.LENGTH_LONG).show()
            } else {
                // Fallback to sharing the file via Share sheet
                shareCodeAsFile(context, project)
            }
        }
    }

    fun shareCodeAsFile(context: Context, project: Project) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val fileName = getFileName(project)
                val tempFile = File(context.cacheDir, fileName)
                FileOutputStream(tempFile).use { out ->
                    out.write(project.sourceCode.toByteArray())
                }

                val authority = "${context.packageName}.fileprovider"
                val uri = FileProvider.getUriForFile(context, authority, tempFile)

                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = if (project.type == "WEBSITE") "text/html" else "text/plain"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, "Code Export - ${project.name}")
                    putExtra(Intent.EXTRA_TEXT, "Here is the source code generated via ABHAY DEV AI: ${project.name}")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }

                withContext(Dispatchers.Main) {
                    context.startActivity(Intent.createChooser(intent, "Export Clean Source Code"))
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Error sharing code: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun getFileName(project: Project): String {
        val cleanName = project.name.replace("[^a-zA-Z0-9]".toRegex(), "_")
        return if (project.type == "WEBSITE") {
            "$cleanName.html"
        } else {
            "${cleanName}_MainActivity.kt"
        }
    }

    private fun buildPromptText(prompt: String, type: String): String {
        return """
        You are an expert AI software developer. The user wants to build a ${if (type == "WEBSITE") "Website" else "Android App (Kotlin & Jetpack Compose)"}.
        User Prompt: "$prompt"

        Respond with a strictly formatted JSON object that perfectly matches this structure:
        {
          "name": "Creative title of the project based on prompt",
          "type": "${if (type == "WEBSITE") "WEBSITE" else "ANDROID_APP"}",
          "sourceCode": "Insert the complete clean source code here...",
          "previewConfig": {
            "themeColor": "#xxxxxx (A beautiful hex color matching the project's brand identity)",
            "components": [
               ... (A list of 4-8 interactive simulated components for ANDROID_APP, or empty list for WEBSITE)
            ]
          }
        }

        Rules for WEBSITE:
        1. In `sourceCode`, return the COMPLETE, fully functional single-page HTML string (with inline CSS or Tailwind CSS loaded via CDN, and interactive JavaScript).
        2. Set `previewConfig` to null or keep components empty.
        3. Make the design highly modern, beautiful, mobile-friendly, and interactive.

        Rules for ANDROID_APP:
        1. In `sourceCode`, write a clean, compilable Kotlin file containing a complete Jetpack Compose screen. It MUST include:
           - Full packages & imports (androidx.compose.*, androidx.compose.material3.*, etc.)
           - A primary @Composable function representing the full layout (matching modern Material 3 design).
           - Beautiful typography, states (remember, mutableStateOf), and interactions.
        2. In `previewConfig`, provide a list of visual components matching your Kotlin design, so our phone emulator can render it interactively!
           Supported component types (each object must have 'type' and properties):
           - {"type": "header", "title": "App Name", "subtitle": "Tagline"}
           - {"type": "text", "text": "Paragraph of text", "icon": "star/settings/person/home/info (optional)"}
           - {"type": "button", "label": "Button action", "actionMessage": "Toast notification text displayed when user taps it"}
           - {"type": "textField", "label": "Input Label", "placeholder": "Sample hint text"}
           - {"type": "card", "title": "Card Title", "text": "Card body description", "icon": "info (optional)"}
           - {"type": "switch", "label": "Feature Toggle State"}
           - {"type": "checkbox", "label": "Task checkbox item"}
           - {"type": "imagePlaceholder", "label": "Hero illustration or user avatar image placeholder description"}
           - {"type": "spacer", "heightDp": 16}

        IMPORTANT: Response must be a single valid JSON block. Do not add any conversational text before or after the JSON.
        """.trimIndent()
    }
}

class ProjectViewModelFactory(
    private val application: Application,
    private val repository: ProjectRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ProjectViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ProjectViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
