package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Project
import com.example.ui.ProjectViewModel
import com.example.ui.ChatMessage
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.clickable
import com.example.ui.components.MobileSimulator
import com.example.ui.components.WebsitePreview
import com.example.ui.theme.StudioBlue
import com.example.ui.theme.StudioPurple
import com.example.ui.theme.StudioTeal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkspaceScreen(
    viewModel: ProjectViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val project by viewModel.selectedProject.collectAsState()
    val context = LocalContext.current

    // Navigation fallback if null
    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val currentProject = project!!
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Real-time Preview", "Source Code", "Refine with AI", "Publish")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = currentProject.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = if (currentProject.type == "WEBSITE") "Static Website" else "Android App Layout",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back Button")
                    }
                },
                actions = {
                    // Quick Download Code action button in top bar
                    IconButton(onClick = { viewModel.downloadCode(context, currentProject) }) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Quick Download Code",
                            tint = if (currentProject.type == "WEBSITE") StudioTeal else StudioBlue
                        )
                    }
                    // Quick Share Code button
                    IconButton(onClick = { viewModel.shareCodeAsFile(context, currentProject) }) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share Code",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Material 3 Primary Tab Row to navigate workspace modes
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = if (currentProject.type == "WEBSITE") StudioTeal else StudioBlue
                    )
                }
            ) {
                tabs.forEachIndexed { index, label ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = label,
                                fontSize = 13.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }
            }

            // Tab Page Contents
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (selectedTab) {
                    0 -> {
                        // 1. Live Preview Content
                        if (currentProject.type == "WEBSITE") {
                            WebsitePreview(htmlContent = currentProject.sourceCode)
                        } else {
                            MobileSimulator(
                                previewConfigJson = currentProject.previewConfigJson,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    1 -> {
                        // 2. Monospaced Source Code View
                        SourceCodeTabContent(
                            project = currentProject,
                            onCopy = {
                                viewModel.copyToClipboard(context, currentProject.sourceCode)
                            },
                            onDownload = {
                                viewModel.downloadCode(context, currentProject)
                            }
                        )
                    }

                    2 -> {
                        // 3. AI Refinement Chat Tab Content
                        AiChatRefineTabContent(viewModel = viewModel)
                    }

                    3 -> {
                        // 4. Publish Tab Content
                        PublishTabContent(
                            project = currentProject,
                            onPublishClick = {
                                viewModel.publishProject(currentProject)
                            },
                            onCopyLink = { url ->
                                viewModel.copyToClipboard(context, url, "Published Link")
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SourceCodeTabContent(
    project: Project,
    onCopy: () -> Unit,
    onDownload: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Code Info",
                        tint = if (project.type == "WEBSITE") StudioTeal else StudioBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (project.type == "WEBSITE") {
                            "This is static clean HTML5/CSS3 source code. It includes inline responsive styles and functional JavaScript."
                        } else {
                            "This is clean compilable Kotlin Jetpack Compose code with material themes, layout alignments, and reactive state handles."
                        },
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 16.sp
                    )
                }
            }

            // Monospaced Code Terminal Block
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0B132B), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFF1C2541), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = project.sourceCode,
                    color = Color(0xFFE0E1DD),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(60.dp)) // Padding at bottom for floating buttons
        }

        // Action Buttons at bottom of code viewport
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, MaterialTheme.colorScheme.background.copy(alpha = 0.95f))
                    )
                )
                .padding(20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onCopy,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = if (project.type == "WEBSITE") StudioTeal else StudioBlue)
            ) {
                Icon(Icons.Default.ContentCopy, "Copy")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Copy Code", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onDownload,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (project.type == "WEBSITE") StudioTeal else StudioBlue)
            ) {
                Icon(Icons.Default.Download, "Download")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Download File", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PublishTabContent(
    project: Project,
    onPublishClick: () -> Unit,
    onCopyLink: (String) -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (!project.isPublished) {
            // State: NOT Published yet
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .background(StudioPurple.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CloudQueue,
                    contentDescription = "Cloud Icon",
                    tint = StudioPurple,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Deploy to Web / App Store",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (project.type == "WEBSITE") {
                    "Publish your static website instantly with direct global hosting, a clean custom URL, and interactive web sharing."
                } else {
                    "Assemble your package into a secure mock cloud repository and generate a secure APK installation link with QR code."
                },
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = onPublishClick,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = StudioPurple),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Icon(Icons.Default.RocketLaunch, "Publish")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Publish Direct", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        } else {
            // State: Successfully Published!
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = borderCardBorder(StudioTeal.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(StudioTeal.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Check, "Success", tint = StudioTeal, modifier = Modifier.size(16.dp))
                        }
                        Column {
                            Text(
                                text = "Successfully Deployed!",
                                fontWeight = FontWeight.ExtraBold,
                                color = StudioTeal,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Hosting assets online & configured SSL.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    // Generated QR Code visual illustration on Canvas
                    Text(
                        text = if (project.type == "WEBSITE") "Scan QR to View Live Website" else "Scan QR to Download App APK",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    InteractiveQRCodeCanvas(themeColor = if (project.type == "WEBSITE") StudioTeal else StudioBlue)

                    // Generated Live Link Card
                    OutlinedCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.outlinedCardColors(containerColor = MaterialTheme.colorScheme.background)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(
                                imageVector = if (project.type == "WEBSITE") Icons.Default.Link else Icons.Default.FileDownload,
                                contentDescription = "Link",
                                tint = if (project.type == "WEBSITE") StudioTeal else StudioBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = project.publishedUrl,
                                color = if (project.type == "WEBSITE") StudioTeal else StudioBlue,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 8.dp)
                            )
                            IconButton(
                                onClick = { onCopyLink(project.publishedUrl) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, "Copy", modifier = Modifier.size(14.dp))
                            }
                        }
                    }

                    // Native URL triggers or share
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "Check out my AI creation!")
                                    putExtra(Intent.EXTRA_TEXT, "Look at the project I built and published using ABHAY DEV AI: ${project.publishedUrl}")
                                }
                                context.startActivity(Intent.createChooser(intent, "Share Link"))
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Share, "Share", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share Link", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                val openUrlIntent = Intent(Intent.ACTION_VIEW, Uri.parse(project.publishedUrl))
                                context.startActivity(openUrlIntent)
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = if (project.type == "WEBSITE") StudioTeal else StudioBlue)
                        ) {
                            Icon(
                                imageVector = if (project.type == "WEBSITE") Icons.Default.OpenInNew else Icons.Default.Download,
                                contentDescription = "View",
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (project.type == "WEBSITE") "Open Page" else "Get APK", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// Generate an elegant physical QR Code design on-the-fly using canvas
@Composable
fun InteractiveQRCodeCanvas(themeColor: Color) {
    Canvas(
        modifier = Modifier
            .size(140.dp)
            .background(Color.White, RoundedCornerShape(16.dp))
            .border(2.dp, themeColor.copy(alpha = 0.15f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        val sizePx = size.width
        val blocks = 13 // 13x13 grid representation for neat styling
        val blockSize = sizePx / blocks

        // Draw structural QR corner locator squares (Top Left, Top Right, Bottom Left)
        val locatorPositions = listOf(
            Offset(0f, 0f),
            Offset(sizePx - 4 * blockSize, 0f),
            Offset(0f, sizePx - 4 * blockSize)
        )

        locatorPositions.forEach { pos ->
            // Outer frame
            drawRect(
                color = themeColor,
                topLeft = pos,
                size = Size(4 * blockSize, 4 * blockSize)
            )
            // Inner mask
            drawRect(
                color = Color.White,
                topLeft = Offset(pos.x + blockSize, pos.y + blockSize),
                size = Size(2 * blockSize, 2 * blockSize)
            )
            // Core pixel
            drawRect(
                color = themeColor,
                topLeft = Offset(pos.x + 1.25f * blockSize, pos.y + 1.25f * blockSize),
                size = Size(1.5f * blockSize, 1.5f * blockSize)
            )
        }

        // Generate stylized, high-contrast, repeatable pseudo-random pixel patterns for the remaining grid
        val patternSeed = 42L
        val random = java.util.Random(patternSeed)

        for (r in 0 until blocks) {
            for (c in 0 until blocks) {
                // Skip corner locator zones (4x4 tiles in top-left, top-right, bottom-left)
                val isTopLeftLocator = r < 4 && c < 4
                val isTopRightLocator = r < 4 && c >= blocks - 4
                val isBottomLeftLocator = r >= blocks - 4 && c < 4

                if (!isTopLeftLocator && !isTopRightLocator && !isBottomLeftLocator) {
                    if (random.nextBoolean()) {
                        drawRect(
                            color = if (random.nextBoolean()) themeColor else Color.Black.copy(alpha = 0.85f),
                            topLeft = Offset(c * blockSize, r * blockSize),
                            size = Size(blockSize, blockSize)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiChatRefineTabContent(
    viewModel: ProjectViewModel
) {
    val chatMessages by viewModel.chatMessages.collectAsState()
    var inputMessage by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val listState = rememberLazyListState()

    // Automatically scroll to bottom when a new message is added
    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Descriptive Header Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = StudioPurple.copy(alpha = 0.08f)
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI Magic Icon",
                    tint = StudioPurple,
                    modifier = Modifier.size(24.dp)
                )
                Column {
                    Text(
                        text = "AI Live Chat Editor",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Describe changes in Hindi or English. AI will modify this project instantly!",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Error Banner
        errorMessage?.let { error ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = "Error Icon",
                        tint = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Text(
                        text = error,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 11.sp,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { errorMessage = null },
                        modifier = Modifier.size(20.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss Error",
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }

        // Messages List Container
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(chatMessages) { message ->
                ChatBubble(message = message)
            }

            if (isSending) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(12.dp),
                                    strokeWidth = 1.5.dp,
                                    color = StudioPurple
                                )
                                Text(
                                    text = "AI is rewriting code...",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Predefined suggestions chips
        val suggestions = listOf(
            "Change to Dark Mode" to "is app ko fully modern dark theme me convert kare, and bright colors use kare layout details me.",
            "Translate layout to Hindi" to "Translate all buttons, headers and fields to clean and neat Hindi language.",
            "Add visual layout improvements" to "Is layout me visual design improve kare, components rounded aur spacing modern kare.",
            "Add Contact Section" to "Add a neat and clean contact support section in this layout at the bottom."
        )

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(suggestions) { item ->
                SuggestionChip(
                    onClick = {
                        if (!isSending) {
                            inputMessage = item.second
                        }
                    },
                    label = {
                        Text(
                            text = item.first,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                )
            }
        }

        // Input bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            tonalElevation = 2.dp,
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputMessage,
                    onValueChange = { inputMessage = it },
                    placeholder = {
                        Text(
                            text = "Describe changes in Hindi or English...",
                            fontSize = 13.sp
                        )
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp),
                    maxLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudioPurple
                    ),
                    enabled = !isSending
                )

                FilledIconButton(
                    onClick = {
                        if (inputMessage.isBlank()) return@FilledIconButton
                        val messageText = inputMessage
                        inputMessage = ""
                        isSending = true
                        errorMessage = null

                        // Add user message to history
                        viewModel.addChatMessage(
                            ChatMessage(text = messageText, isUser = true)
                        )

                        viewModel.refineProjectWithAi(
                            userMessage = messageText,
                            onSuccess = { confirm ->
                                isSending = false
                                viewModel.addChatMessage(
                                    ChatMessage(text = confirm, isUser = false)
                                )
                            },
                            onError = { err ->
                                isSending = false
                                errorMessage = err
                                viewModel.addChatMessage(
                                    ChatMessage(
                                        text = "⚠️ Failed to modify the project: $err",
                                        isUser = false
                                    )
                                )
                            }
                        )
                    },
                    modifier = Modifier.size(44.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = StudioPurple
                    ),
                    enabled = !isSending && inputMessage.isNotBlank()
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send Message",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val alignment = if (message.isUser) Alignment.End else Alignment.Start
    val containerColor = if (message.isUser) {
        StudioPurple.copy(alpha = 0.9f)
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }
    val contentColor = if (message.isUser) {
        Color.White
    } else {
        MaterialTheme.colorScheme.onSurface
    }
    val shape = if (message.isUser) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 2.dp)
    } else {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 2.dp, bottomEnd = 16.dp)
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(0.85f),
            horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start,
            verticalAlignment = Alignment.Top
        ) {
            if (!message.isUser) {
                Box(
                    modifier = Modifier
                        .padding(end = 6.dp, top = 2.dp)
                        .size(24.dp)
                        .background(StudioPurple.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "AI Avatar",
                        tint = StudioPurple,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            Surface(
                color = containerColor,
                contentColor = contentColor,
                shape = shape,
                tonalElevation = 1.dp
            ) {
                Text(
                    text = message.text,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        }
    }
}
