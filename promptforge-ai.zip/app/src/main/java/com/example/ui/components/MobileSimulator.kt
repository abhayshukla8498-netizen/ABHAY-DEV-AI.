package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.api.PreviewComponent
import com.example.api.PreviewConfig
import com.example.ui.theme.StudioTeal
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MobileSimulator(
    previewConfigJson: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Parse configuration
    val config = remember(previewConfigJson) {
        try {
            val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
            val adapter = moshi.adapter(PreviewConfig::class.java)
            adapter.fromJson(previewConfigJson) ?: PreviewConfig()
        } catch (e: Exception) {
            PreviewConfig(
                themeColor = "#0F62FE",
                components = listOf(
                    PreviewComponent(
                        type = "header",
                        title = "App Simulation",
                        subtitle = "Live View"
                    ),
                    PreviewComponent(
                        type = "text",
                        text = "Interactive preview configuration failed to load. Showing base screen."
                    )
                )
            )
        }
    }

    val themeColor = remember(config.themeColor) {
        try {
            Color(android.graphics.Color.parseColor(config.themeColor ?: "#0F62FE"))
        } catch (e: Exception) {
            Color(0xFF0F62FE)
        }
    }

    // Keep track of reactive simulation states (e.g., text inputs, switches, checkboxes, custom logs)
    val inputStates = remember { mutableStateMapOf<String, String>() }
    val switchStates = remember { mutableStateMapOf<String, Boolean>() }
    val checkboxStates = remember { mutableStateMapOf<String, Boolean>() }
    var activeActionLog by remember { mutableStateOf<String?>(null) }

    var simulatedComponents by remember(config.components) {
        mutableStateOf(config.components ?: emptyList())
    }
    var calculatorDisplay by remember { mutableStateOf("") }

    // Main content box directly rendering the live preview, filling the full container size
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
                    items(simulatedComponents) { component ->
                        when (component.type) {
                            "header" -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(themeColor)
                                        .padding(horizontal = 16.dp, vertical = 20.dp)
                                ) {
                                    Column {
                                        Text(
                                            text = component.title ?: "My AI App",
                                            color = Color.White,
                                            fontSize = 22.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                        if (!component.subtitle.isNullOrBlank()) {
                                            Text(
                                                text = component.subtitle,
                                                color = Color.White.copy(alpha = 0.8f),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Normal,
                                                modifier = Modifier.padding(top = 4.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            "text" -> {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    val icon = mapStringToIcon(component.icon)
                                    if (icon != null) {
                                        Icon(
                                            imageVector = icon,
                                            contentDescription = "Icon",
                                            tint = themeColor,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Text(
                                        text = component.text ?: "",
                                        fontSize = 15.sp,
                                        lineHeight = 22.sp,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                            }

                            "button" -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Button(
                                        onClick = {
                                            val label = component.label ?: ""
                                            val msg = component.actionMessage ?: "Button clicked!"
                                            activeActionLog = "Action Triggered: $msg"
                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

                                            // 1. Todo App Simulation logic:
                                            if (label.contains("Add", ignoreCase = true) || 
                                                label.contains("Create", ignoreCase = true) || 
                                                label.contains("Submit", ignoreCase = true)) {
                                                // Find if there is any textField component
                                                val textFieldComponent = simulatedComponents.firstOrNull { it.type == "textField" }
                                                val key = textFieldComponent?.label ?: "input"
                                                val typedText = inputStates[key] ?: ""
                                                if (typedText.isNotBlank()) {
                                                    val newComponent = PreviewComponent(
                                                        type = "checkbox",
                                                        label = typedText
                                                    )
                                                    simulatedComponents = simulatedComponents + newComponent
                                                    inputStates[key] = "" // clear input text
                                                }
                                            }

                                            // 2. Authentication & Screen Switch Simulation logic:
                                            else if (label.contains("Login", ignoreCase = true) || 
                                                     label.contains("Sign In", ignoreCase = true) || 
                                                     label.contains("Sign Up", ignoreCase = true) ||
                                                     label.contains("Register", ignoreCase = true)) {
                                                val emailField = simulatedComponents.firstOrNull { it.type == "textField" && (it.label?.contains("Email", ignoreCase = true) ?: false) }
                                                val emailKey = emailField?.label ?: "input"
                                                val emailVal = inputStates[emailKey] ?: ""
                                                
                                                simulatedComponents = listOf(
                                                    PreviewComponent(
                                                        type = "header",
                                                        title = "Dashboard Portal 🚀",
                                                        subtitle = if (emailVal.isNotBlank()) "Signed in as $emailVal" else "Logged in as Creator"
                                                    ),
                                                    PreviewComponent(
                                                        type = "card",
                                                        title = "Interactive Control Panel",
                                                        text = "• Firebase Session: Active\n• Database Sync: Connected\n• Security handshakes: OK\n• Dynamic data streams: Live",
                                                        icon = "home"
                                                    ),
                                                    PreviewComponent(
                                                        type = "text",
                                                        text = "This screen simulates the interior dashboard of your compiled Android App once authenticated. Tap the button below to sign out."
                                                    ),
                                                    PreviewComponent(
                                                        type = "button",
                                                        label = "Sign Out & Return",
                                                        actionMessage = "Simulating sign out protocol..."
                                                    )
                                                )
                                            }

                                            // 3. Logout restore:
                                            else if (label.contains("Sign Out", ignoreCase = true) || 
                                                     label.contains("Logout", ignoreCase = true) || 
                                                     label.contains("Return", ignoreCase = true)) {
                                                simulatedComponents = config.components ?: emptyList()
                                            }

                                            // 4. Calculator keypad key simulation:
                                            else {
                                                val isCalcKey = label.length == 1 && (label[0].isDigit() || "+-*/C=.".contains(label[0]))
                                                if (isCalcKey || label.contains("Clear", ignoreCase = true) || label == "=") {
                                                    if (label == "C" || label.contains("Clear", ignoreCase = true)) {
                                                        calculatorDisplay = ""
                                                    } else if (label == "=") {
                                                        val cleanExpr = calculatorDisplay.replace("x", "*").replace("÷", "/")
                                                        val tokens = cleanExpr.split(Regex("(?<=[-+*/])|(?=[-+*/])"))
                                                        if (tokens.isNotEmpty()) {
                                                            var hasError = false
                                                            var errorMsg = ""
                                                            try {
                                                                var result = tokens[0].trim().toDoubleOrNull() ?: 0.0
                                                                var i = 1
                                                                while (i < tokens.size && !hasError) {
                                                                    val op = tokens[i].trim()
                                                                    if (i + 1 < tokens.size) {
                                                                        val nextVal = tokens[i + 1].trim().toDoubleOrNull() ?: 0.0
                                                                        when (op) {
                                                                            "+" -> result += nextVal
                                                                            "-" -> result -= nextVal
                                                                            "*" -> result *= nextVal
                                                                            "/" -> {
                                                                                if (nextVal != 0.0) {
                                                                                    result /= nextVal
                                                                                } else {
                                                                                    hasError = true
                                                                                    errorMsg = "Error: Div by 0"
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                    i += 2
                                                                }
                                                                if (hasError) {
                                                                    calculatorDisplay = errorMsg
                                                                } else {
                                                                    val intRes = result.toInt()
                                                                    calculatorDisplay = if (result == intRes.toDouble()) intRes.toString() else String.format("%.2f", result)
                                                                }
                                                            } catch (e: Exception) {
                                                                calculatorDisplay = "Error"
                                                            }
                                                        }
                                                    } else {
                                                        calculatorDisplay += label
                                                    }

                                                    // Update header or text display dynamically!
                                                    simulatedComponents = simulatedComponents.mapIndexed { idx, comp ->
                                                        if (comp.type == "text" && idx == 1) {
                                                            comp.copy(text = "Result: $calculatorDisplay")
                                                        } else if (comp.type == "header" && idx == 0) {
                                                            comp.copy(subtitle = "Calculation: $calculatorDisplay")
                                                        } else {
                                                            comp.copy()
                                                        }
                                                    }
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(text = component.label ?: "Tap Action", color = Color.White)
                                    }
                                }
                            }

                            "textField" -> {
                                val key = component.label ?: "input"
                                val currentVal = inputStates[key] ?: ""
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = component.label ?: "Input Field",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                                        modifier = Modifier.padding(bottom = 4.dp)
                                    )
                                    OutlinedTextField(
                                        value = currentVal,
                                        onValueChange = { inputStates[key] = it },
                                        placeholder = { Text(component.placeholder ?: "Type here...") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = themeColor,
                                            focusedLabelColor = themeColor
                                        )
                                    )
                                }
                            }

                            "card" -> {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 10.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    ),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val icon = mapStringToIcon(component.icon)
                                        if (icon != null) {
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .background(themeColor.copy(alpha = 0.15f), CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = icon,
                                                    contentDescription = "Card Icon",
                                                    tint = themeColor
                                                )
                                            }
                                        }

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = component.title ?: "Info Title",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            if (!component.text.isNullOrBlank()) {
                                                Text(
                                                    text = component.text,
                                                    fontSize = 13.sp,
                                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                                    modifier = Modifier.padding(top = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            "switch" -> {
                                val key = component.label ?: "switch"
                                val checked = switchStates[key] ?: false
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = component.label ?: "Toggle feature",
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    Switch(
                                        checked = checked,
                                        onCheckedChange = {
                                            switchStates[key] = it
                                            activeActionLog = "Toggled '${component.label}': $it"
                                        },
                                        colors = SwitchDefaults.colors(checkedThumbColor = themeColor, checkedTrackColor = themeColor.copy(alpha = 0.5f))
                                    )
                                }
                            }

                            "checkbox" -> {
                                val key = component.label ?: "checkbox"
                                val checked = checkboxStates[key] ?: false
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.Start,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = checked,
                                        onCheckedChange = {
                                            checkboxStates[key] = it
                                            activeActionLog = "Checkbox '${component.label}': $it"
                                        },
                                        colors = CheckboxDefaults.colors(checkedColor = themeColor)
                                    )
                                    Text(
                                        text = component.label ?: "Task Item",
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onBackground,
                                        modifier = Modifier.padding(start = 6.dp)
                                    )
                                }
                            }

                            "imagePlaceholder" -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp)
                                        .height(component.heightDp?.dp ?: 140.dp)
                                        .background(themeColor.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                                        .border(1.dp, themeColor.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center,
                                        modifier = Modifier.padding(16.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Image,
                                            contentDescription = "Image Banner",
                                            tint = themeColor,
                                            modifier = Modifier.size(36.dp)
                                        )
                                        Text(
                                            text = component.label ?: "Asset Visualizer",
                                            textAlign = TextAlign.Center,
                                            fontSize = 12.sp,
                                            color = themeColor.copy(alpha = 0.8f),
                                            fontWeight = FontWeight.Medium,
                                            modifier = Modifier.padding(top = 8.dp)
                                        )
                                    }
                                }
                            }

                            "spacer" -> {
                                Spacer(modifier = Modifier.height(component.heightDp?.dp ?: 16.dp))
                            }
                        }
                    }
                }

                // Simulated Interactive Floating Output Console at bottom
                activeActionLog?.let { log ->
                    Card(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(12.dp)
                            .fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.inverseSurface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Terminal,
                                contentDescription = "Terminal",
                                tint = StudioTeal,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = log,
                                color = MaterialTheme.colorScheme.inverseOnSurface,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { activeActionLog = null },
                                modifier = Modifier.size(18.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear",
                                    tint = MaterialTheme.colorScheme.inverseOnSurface.copy(alpha = 0.6f),
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
    }
}

// Map string descriptors to Material M3 Vector Icons
private fun mapStringToIcon(iconName: String?): ImageVector? {
    if (iconName == null) return null
    return when (iconName.lowercase().trim()) {
        "home" -> Icons.Default.Home
        "settings", "gear" -> Icons.Default.Settings
        "person", "user", "avatar" -> Icons.Default.Person
        "star", "favorite" -> Icons.Default.Star
        "info" -> Icons.Default.Info
        "cloud", "weather" -> Icons.Default.Cloud
        "shopping", "cart" -> Icons.Default.ShoppingCart
        "notifications", "bell" -> Icons.Default.Notifications
        "email", "mail" -> Icons.Default.Email
        "search" -> Icons.Default.Search
        "phone", "call" -> Icons.Default.Phone
        "map", "gps" -> Icons.Default.Map
        "play", "video" -> Icons.Default.PlayArrow
        "music", "audio" -> Icons.Default.MusicNote
        "camera" -> Icons.Default.CameraAlt
        else -> Icons.Default.AutoAwesome
    }
}
